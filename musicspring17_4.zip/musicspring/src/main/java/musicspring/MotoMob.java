package musicspring;

public class MotoMob {
	private Integer pid;
	private String pname;
    private Integer cost;
    private Integer avail;
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	public Integer getAvail() {
		return avail;
	}
	public void setAvail(Integer avail) {
		this.avail = avail;
	}
    
    
}
